//app.js
App({
  onLaunch: function () {
    
  },
  globalData: {
    userInfo: null,
    sesionTotal: 0
  }
})